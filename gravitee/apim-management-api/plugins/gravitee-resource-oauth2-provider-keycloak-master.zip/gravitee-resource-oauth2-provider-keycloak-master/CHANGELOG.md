## [1.9.2](https://github.com/gravitee-io/gravitee-resource-oauth2-provider-keycloak/compare/1.9.1...1.9.2) (2022-05-02)


### Bug Fixes

* This commit doesn't fix any bugs and was made in order to  a release and so fix publication on download website.
 ([df2ee86](https://github.com/gravitee-io/gravitee-resource-oauth2-provider-keycloak/commit/df2ee8695cf0210fe76bfaa555170eba76c1203d))
